
export class Payment {
  paymentId?:number;
  amountPaid:number;
  paymentDate:Date;
  modeOfPayement:string;
  organizerId:number;
  totalAmount:number;
}
