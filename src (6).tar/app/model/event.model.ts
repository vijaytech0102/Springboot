export class Event{
  eventId?:number=0;
  eventType:string='';
  description:string='';
  participantsCount:number=0;
  eventCharges:number=0;
}
