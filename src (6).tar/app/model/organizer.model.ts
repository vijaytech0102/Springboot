export class Organizer {
  userName:string='';
  mobileNumber:number;
}
