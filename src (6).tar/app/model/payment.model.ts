
export class Payment {
     paymentId?:number;
     amount:number;
     paymentDate:Date;
     modeOfPayement:string;
}
