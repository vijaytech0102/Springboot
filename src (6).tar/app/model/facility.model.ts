export class Facility{
  facilityId?:number=0;
  facilityDescription:string='';
  price:number=0;
}
