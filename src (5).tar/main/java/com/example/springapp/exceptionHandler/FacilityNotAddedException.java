package com.example.springapp.exceptionHandler;


public class FacilityNotAddedException extends Exception{

    public FacilityNotAddedException() {
        super();
    }

    public FacilityNotAddedException(String message) {
        super(message);
    }
    
    
    
}
