package com.example.springapp.exceptionHandler;

public class EventBookedException extends Exception{

    public EventBookedException() {
        super();
    }

    public EventBookedException(String message) {
        super(message);
    }
    
    
}
