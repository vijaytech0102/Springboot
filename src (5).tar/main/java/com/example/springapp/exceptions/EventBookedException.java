package com.example.springapp.exceptions;

public class EventBookedException extends Exception{

    public EventBookedException() {
        super();
    }

    public EventBookedException(String message) {
        super(message);
    }
    
    
}
