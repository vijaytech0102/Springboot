package com.example.springapp.exceptions;

public class NoBodyFoundException extends Exception{

    public NoBodyFoundException() {
        super();
    }

    public NoBodyFoundException(String message) {
        super(message);
    }
    
    
}
