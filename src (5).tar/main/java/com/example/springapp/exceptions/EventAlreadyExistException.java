package com.example.springapp.exceptions;

public class EventAlreadyExistException extends Exception{

    public EventAlreadyExistException() {
        super();
    }

    public EventAlreadyExistException(String message) {
        super(message);
    }
    
    
    
}
